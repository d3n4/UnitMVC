<?php
    abstract class OBModel {

    }